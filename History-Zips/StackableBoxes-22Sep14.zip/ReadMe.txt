Product: Stackable Boxes, September 2014

Designer: Simon Kirkby

Support:  http://forums.obrary.com/category/designs/stackable-boxes

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Stackable Boxes are designed to be printed from plywood on the Laser Cutter.